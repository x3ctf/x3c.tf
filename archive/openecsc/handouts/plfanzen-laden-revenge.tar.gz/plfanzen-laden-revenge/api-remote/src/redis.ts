import { createClient } from "redis";
import { inContainer } from "@/config.ts";

const client = createClient({ url: "redis://localhost:6379" });

await client.connect();

export default client;
