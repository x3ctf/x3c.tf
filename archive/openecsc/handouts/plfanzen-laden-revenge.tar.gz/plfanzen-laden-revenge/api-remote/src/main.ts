import { Application, Router } from "@oak/oak";

import {
  dbMiddleware,
  errorMiddleware,
  rateLimitMiddleware,
  sessionMiddleware,
  userMiddleware,
} from "@/middleware/index.ts";

import { Client } from "@db/postgres";
import { getClient, hardReset, reset } from "@/db/index.ts";
import { UserPublic } from "@/db/users.ts";
import { DB_CONFIG, sessionPrefix } from "@/config.ts";
import {
  authRouter,
  cartRouter,
  productsRouter,
  reviewsRouter,
  usersRouter,
} from "@/routers/index.ts";

import { oakCors } from "https://deno.land/x/cors/mod.ts";
import client from "@/redis.ts";
import { uid } from "@/crypto.ts";

export interface State {
  client: Client;
  session: Record<string, unknown>;
  user?: UserPublic;
}

const app = new Application<State>();
const router = new Router<State>();

const db = await getClient(DB_CONFIG);
await reset(db);

// 🏃🏃🏃
await client.set("FLAG_" + uid(20), Deno.env.get("FLAG") ?? "openECSC{123}", {
  EX: 15,
});

await client.set("greeting", "Heloo", {
  EX: 60,
});

app.use(
  oakCors({
    origin: true,
    credentials: true,
    allowedHeaders: [
      "Content-Type",
      "Authorization",
      "X-Requested-With",
      "Accept",
      "Origin",
    ],
    exposedHeaders: ["Set-Cookie"],
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    preflightContinue: false,
    optionsSuccessStatus: 204,
  }),
);

app.use(errorMiddleware());

router.get("/", async (ctx) => {
  ctx.response.body = (await client.get("greeting")) ?? "hello there :)";
});

app.use(router.routes());
app.use(router.allowedMethods());

app.use(
  rateLimitMiddleware({
    normal: {
      points: 150,
      duration: 15,
    },
    burst: {
      points: 1500,
      duration: 10 * 60,
    },
  }),
);

app.use(
  sessionMiddleware({
    secret: Deno.env.get("SESSION_SECRET") || "meow".repeat(10),
    name: "ssid",
    ttl: 2 * 60 * 60 * 1000,
    prefix: sessionPrefix,
  }),
);

app.use(await dbMiddleware(DB_CONFIG));
app.use(userMiddleware);

app.use(authRouter.routes());
app.use(authRouter.allowedMethods());

app.use(productsRouter.routes());
app.use(productsRouter.allowedMethods());

app.use(cartRouter.routes());
app.use(cartRouter.allowedMethods());

app.use(usersRouter.routes());
app.use(usersRouter.allowedMethods());

app.use(reviewsRouter.routes());
app.use(reviewsRouter.allowedMethods());

// 🏃💨💨💨💨
setInterval(
  async () => {
    console.log(`resetting db & sessions`);
    const db = await getClient(DB_CONFIG);
    await reset(db);
  },
  6 * 60 * 1000,
);

setInterval(
  async () => {
    console.log(`factory reset 😇😇😇`);
    const db = await getClient(DB_CONFIG);
    await hardReset(db);
  },
  15 * 60 * 1000,
);
console.log("Listening on http://0.0.0.0:3000");
await app.listen({ port: 3000 });
