import React from "react";

interface StarProps {
  filled: boolean;
  onClick?: () => void;
  size?: "sm" | "md" | "lg";
  interactive?: boolean;
}

const Star: React.FC<StarProps> = (
  { filled, onClick, size = "md", interactive = false },
) => {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6",
  };

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!interactive}
      className={`
        ${sizeClasses[size]}
        ${filled ? "text-yellow-400" : "text-gray-300"}
        ${
        interactive
          ? "hover:text-yellow-400 focus:outline-none transition-colors cursor-pointer"
          : "cursor-default"
      }
        ${!interactive ? "pointer-events-none" : ""}
      `}
    >
      <svg
        fill="currentColor"
        viewBox="0 0 20 20"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
      </svg>
    </button>
  );
};

export default Star;
