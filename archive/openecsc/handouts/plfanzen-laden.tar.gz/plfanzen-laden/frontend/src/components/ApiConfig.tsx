import React from "react";
import ApiConfiguration from "./ApiConfiguration";

interface ApiConfigProps {
  onApiUrlSet: (url: string) => void;
}

const ApiConfig: React.FC<ApiConfigProps> = ({ onApiUrlSet }) => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <img
            className="h-12 w-auto"
            src="/plfanzen.svg"
            alt="Pflänzen Logo"
          />
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900 dark:text-white">
          Schnittstellen-Konfiguration
        </h2>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white dark:bg-gray-800 py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <ApiConfiguration 
            onSuccess={onApiUrlSet}
            showTitle={false}
          />
        </div>
      </div>
    </div>
  );
};

export default ApiConfig;
