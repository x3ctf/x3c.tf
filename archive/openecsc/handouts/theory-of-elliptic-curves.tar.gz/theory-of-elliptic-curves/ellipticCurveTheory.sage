proof.all(False)

from Crypto.Util.number import long_to_bytes as ltb
from os import environ

def isCool(val, coolmsg):
	return ltb(int(val)).endswith(coolmsg)

def curveIsCoolAndBased(p, a, b, order):

	# base ring modulus must be prime
	if not is_pseudoprime(p):
		print(f'Non-prime p')
		return False

	# can't have you cheese this challenge
	if p.bit_length() < 400:
		print(f'Too small p')
		return False

	# can't have the infra turn into cheese
	if p.bit_length() > 800:
		print(f'Too big p')
		return False

	# Make sure a and b work
	if not is_pseudoprime(a) or not is_pseudoprime(b) or a >= p or b >= p:
		print(f'a or b don\'t work')
		return False

	# Make sure curve is not backdoored
	if not isCool(a, b'notbackdoored!'):
		print(f'Curve is backdoored')
		return False
	
	# Make sure order is based!
	if not isCool(order, b'based!') or not is_pseudoprime(order):
		print(f'Curve isn\'t based')
		return False

	# Lying is not based!
	K = GF(p)
	E = EllipticCurve(K, [a, b])
	if not E.has_order(order):
		print(f'Lying is not based!')
		return False
	E.set_order(order)

	# Curve must be related to the event
	if not isCool(p, b'OpenECSC'):
		print(f'Unrelated curve')
		return False

	return True

print('Hello friend. Please enter a cool and based curve')
oldP = 0
rounds = 10
for rnd in range(rounds):
	p = int(input())
	a = int(input())
	b = int(input())
	order = int(input())

	if p.bit_length() <= oldP.bit_length():
		print('Curve is insecure')
		exit(0)

	if not curveIsCoolAndBased(p, a, b, order):
		print('That curve is not cool or based!')
		exit(0)

	if rnd != rounds - 1:
		print('Great, but I think we need a curve with better security')
		oldP = p

print(os.environ.get('FLAG', 'OpenECSC{test_flag}'))
